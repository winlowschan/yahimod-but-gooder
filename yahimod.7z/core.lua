--- STEAMODDED HEADER
--- MOD_NAME: Yahimod
--- MOD_ID: Yahimod
--- MOD_AUTHOR: Yahiamice
--- MOD_DESCRIPTION: hi
--- PREFIX: yahi
----------------------------------------------------------
----------- MOD CODE -------------------------------------

SMODS.Atlas{
    key = 'Jokers',
    path = 'Jokers.png',
    px = 71,
    py = 95,
}

SMODS.Joker{
    key = 'joker2',
    loc_txt= {
        name = 'Lazy Joker',
        text = { 'cba making a proper {C:attention} image for this',
                '{X:mult,C:white}X#1#{} Mult' }
    },
    atlas = 'Jokers',
    rarity = 1,
    cost = 4,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = false,

    pos = {x=0, y= 0},
    config = { extra = {
        Xmult = 21
    }},

    loc_vars = function(self,info_queue,center)
        return {vars = {center.ability.extra.Xmult}}
    end,

    check_for_unlock = function(self, args)
        if args.type == 'test' then --not a real type, just a joke
            unlock_card(self)
        end
        unlock_card(self) --unlocks the card if it isnt unlocked
    end,

    calculate = function(self,card,context)
        if context.joker_main then
            return{
                card = card,
                Xmult_mod = card.ability.extra.Xmult,
                message = 'X' .. card.ability.extra.Xmult,
                colour = G.C.MULT

            }
        end

        if context.setting_blind then
            local new_card = create_card('Joker', G.jokers, nil, nil, nil, nil, 'j_joker')
            new_card:add_to_deck()
            G.jokers:emplace(new_card)
        end
    end,

    in_pool = function(self,wawa,wawa2)
        --whether or not this card is in the pool, return true if it is, return false if its not
        return true
    end,
    calc_dollar_bonus = function(self,card)
        return 123
    end,
}

SMODS.Atlas{
    key = 'marx',
    path = 'marx.png',
    px = 71,
    py = 95,
}

SMODS.Joker{
    key = 'marx',
    loc_txt= {
        name = 'Marx',
        text = { "Gains {X:mult,C:white} X#1# {} Mult every time a",
                    "scored {C:attention}Lucky{} card {C:red}DOESN'T{} trigger",
                    "{C:inactive}Resets when a {}{C:attention}Lucky card{} {C:inactive}triggers{}",
                    "{C:inactive}(Currently {X:mult,C:white} X#2# {C:inactive} Mult)",}
    },
    atlas = 'marx',
    rarity = 1,
    cost = 4,
    
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = false,

    pos = {x=0, y= 0},
    config = { extra = {Xmult = 1, additional = 0.25}},
    enhancement_gate = 'm_lucky',

    loc_vars = function(self, info_queue, center)
		info_queue[#info_queue + 1] = G.P_CENTERS.m_lucky
		return { vars = { center.ability.extra.additional , center.ability.extra.Xmult}  }
	end,

    calculate = function(self, card, context)
		if context.joker_main and (card.ability.extra.Xmult > 1) then
			return {
				message = localize({ type = "variable", key = "a_xmult", vars = { card.ability.extra.Xmult } }),
				Xmult_mod = card.ability.extra.Xmult
			}
		end
        if context.individual and context.cardarea == G.play and context.other_card.ability.name == 'Lucky Card' and not context.other_card.lucky_trigger then
            card.ability.extra.Xmult = card.ability.extra.Xmult + card.ability.extra.additional
            return {
                message = "Unlucky!",
                colour = G.C.RED
            }
        end
        if context.individual and context.other_card.lucky_trigger then
            card.ability.extra.Xmult = 1
            return {
                message = ":p",
                colour = G.C.RED
            }
		end
    end,

    check_for_unlock = function(self, args)
        if args.type == 'test' then --not a real type, just a joke
            unlock_card(self)
        end
        unlock_card(self) --unlocks the card if it isnt unlocked
    end,
}

SMODS.Atlas{
    key = 'lcdirects',
    path = 'lcdirects.png',
    px = 71,
    py = 95,
}

SMODS.Joker{
    key = 'lcdirects',
    loc_txt= {
        name = 'LCDirects',
        text = { "Gains {X:mult,C:white} X#1# {} Mult every time a",
                    "Joker or playing card {C:red}is destroyed{}",
                    "{C:inactive}(Currently {X:mult,C:white} X#2# {C:inactive} Mult)",
                    "",
                    "{C:inactive}``WHAT AM I GONNA DO WITH HALF A MULT?!``{}"
    }},
    atlas = 'lcdirects',
    rarity = 2,
    cost = 5,
    
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = false,

    pos = {x=0, y= 0},
    config = { extra = {Xmult = 1, additional = 0.5}},

    loc_vars = function(self, info_queue, center)
		return { vars = { center.ability.extra.additional , center.ability.extra.Xmult}  }
	end,

    

    calculate = function(self, card, context)
		if context.joker_main and (card.ability.extra.Xmult > 1) then
			return {
				message = localize({ type = "variable", key = "a_xmult", vars = { card.ability.extra.Xmult } }),
				Xmult_mod = card.ability.extra.Xmult
			}
		end
        if context.remove_playing_cards then
            for k, val in ipairs(context.removed) do
                card.ability.extra.Xmult = card.ability.extra.Xmult + card.ability.extra.additional
                return {
                    message = "BOOM!",
                    colour = G.C.RED
                }
            end
        end

        if G.hasajokerbeendestroyedthistick == true then
            G.hasajokerbeendestroyedthistick = false
            card.ability.extra.Xmult = card.ability.extra.Xmult + card.ability.extra.additional
            return {
                message = "BOOM!",
                colour = G.C.RED 
            }
        end

        if context.using_consumeable then
            if context.consumeable.ability.name == 'Hex' or context.consumeable.ability.name == 'Ankh' then
                G.hasajokerbeendestroyedthistick = true
            end
        end

    end,

    check_for_unlock = function(self, args)
        if args.type == 'test' then --not a real type, just a joke
            unlock_card(self)
        end
        unlock_card(self) --unlocks the card if it isnt unlocked
    end,


}

SMODS.Atlas{
    key = '21kid',
    path = '21kid.png',
    px = 71,
    py = 95,
}

SMODS.Sound({key = "nine", path = "nine.ogg",})
SMODS.Sound({key = "ten", path = "ten.ogg",})
SMODS.Sound({key = "twennyone", path = "twennyone.ogg",})

SMODS.Joker{
    key = '21kid',
    loc_txt= {
        name = '21 Kid',
        text = { "{X:mult,C:white} X#1# {} Mult if scored hand" ,
                    "contains a {C:attention}9{} and a {}{C:attention}10{}"}
    },
    atlas = '21kid',
    rarity = 1,
    cost = 4,
    
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = false,

    pos = {x=0, y= 0},
    config = { extra = {Xmult = 2.1}},

    loc_vars = function(self, info_queue, center)
		return { vars = { center.ability.extra.Xmult}  }
	end,

    calculate = function(self, card, context)
		if context.joker_main then
            local hasnine = false
            local hasten = false
            for i = 1, #context.full_hand do
				if context.full_hand[i]:get_id() == 9 then
                    hasnine = true
                end
                if context.full_hand[i]:get_id() == 10 then
                    hasten = true
                end
            end

            if hasnine == true and hasten == true then   
			return {
				message = "21!",
				Xmult_mod = card.ability.extra.Xmult,
                sound= "yahimod_twennyone",
			}
            end
		end

        
        if context.cardarea == G.play and context.individual and context.other_card then
            local rank = context.other_card:get_id()
			if rank == 9 then
				return {
                    sound = 'yahimod_nine'
                }
			end
            if rank == 10 then
				return {
                    sound = 'yahimod_ten'
                }
			end
		end

    end,

    check_for_unlock = function(self, args)
        if args.type == 'test' then --not a real type, just a joke
            unlock_card(self)
        end
        unlock_card(self) --unlocks the card if it isnt unlocked
    end,
}

SMODS.Atlas{
    key = 'jackblack',
    path = 'jackblack.png',
    px = 70,
    py = 95,
}

SMODS.Joker{
    key = 'jackblack',
    loc_txt= {
        name = 'Jack Black',
        text = { "{X:mult,C:white} X#2# {} Mult for every",
                    "{C:attention}Jack{} in your full deck",
                    "{C:inactive}(Currently {X:mult,C:white} X#1# {C:inactive} Mult)",
    },},
    atlas = 'jackblack',
    rarity = 3,
    cost = 4,
    
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = false,

    pos = {x=0, y= 0},
    config = { extra = {Xmult = 0, additional = 0.5}},

    loc_vars = function(self, info_queue, center)
		return { vars = { center.ability.extra.Xmult, center.ability.extra.additional}  }
	end,

    calculate = function(self, card, context)
    if G.playing_cards then
        local jackamount = G.playing_cards and calculate_jack_amount() or 0
        Xmult_mod = (card.ability.extra.additional * jackamount)
        card.ability.extra.Xmult = Xmult_mod
    end
    if context.joker_main then
        return 
            {
            Xmult = Xmult_mod,
            }
        end
    end,

    check_for_unlock = function(self, args)
        if args.type == 'test' then --not a real type, just a joke
            unlock_card(self)
        end
        unlock_card(self) --unlocks the card if it isnt unlocked
    end,
}


init = function(self)
    -- Hook for scaling
    if not Yahimod then Yahimod = {} end
    if not Yahimod.LydiaScale then Yahimod.LydiaScale = 1 end
    local scie = SMODS.calculate_individual_effect
    function SMODS.calculate_individual_effect(effect, scored_card, key, amount, from_edition)
        if
        (
            key == "x_mult"
            or key == "xmult"
            or key == "Xmult"
            or key == "x_mult_mod"
            or key == "xmult_mod"
            or key == "Xmult_mod"
        ) and amount ~= 1
        then
            Yahimod.LydiaScale = Yahimod.LydiaScale * amount
            amount = 1
        end
        local ret = scie(effect, scored_card, key, amount, from_edition)
        return ret
    end
end

SMODS.Atlas{
    key = 'lydia',
    path = 'lydia.png',
    px = 71,
    py = 95,
}

SMODS.Joker{
    key = 'yahimod_lydia',
    loc_txt= {
        name = 'Lydia',
        text = { "Stores all your {X:mult,C:white}XMult{}" ,
                    "and unleashes it on the {C:attention}final hand{}",
                    "{C:inactive}(Stockpiled: {X:mult,C:white} X#1# {C:inactive} Mult)",}
    },
    atlas = 'lydia',
    rarity = 3,
    cost = 10,
    
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    demicoloncompat = true,

    pos = {x=0, y= 0},

    loc_vars = function(self, info_queue, center)
        return { vars = { Yahimod.LydiaScale }}
    end,

    calculate = function(self, card, context)
        if (G.GAME.current_round.hands_left == 0 and context.final_scoring_step and Yahimod.LydiaScale > 1) or context.forcetrigger then
            return {
                message = 'X' .. xmult_mod,
                xmult = Yahimod.LydiaScale
            }
        end
    end,

}






















local upd = Game.update
function Game:update(dt)
    upd(self, dt)
    if G.jokers then
        for i = 1, #G.jokers.cards do
            if G.jokers.cards[i].getting_sliced == true and not G.hasajokerbeendestroyedthistick == true then
                G.hasajokerbeendestroyedthistick = true
                return {
                    print("found a joker being destroyed! adding Mult")
                }
            end
        end
    end

    

    

    calculate = function(self, card, context)
        if context.using_consumeable and context.consumeable.ability.set == 'Ankh' and not G.hasajokerbeendestroyedthistick == true then
            G.hasajokerbeendestroyedthistick = true
            print("Ankh hardcoded")
        end
        if context.using_consumeable and context.consumeable.ability.set == 'Hex' and not G.hasajokerbeendestroyedthistick == true then
            G.hasajokerbeendestroyedthistick = true
            print("Hex hardcoded")
        end
    end
end


    

function calculate_jack_amount()
    local count = 0
    for _, card in ipairs(G.playing_cards) do
        local rank = card.base.value
        if rank == "Jack" then
            count = count + 1
        end
    end
    return count
end


--for i = 1, #G.jokers.cards do
--    if G.jokers.cards[i].getting_sliced == true then
--
--        G.hasajokerbeendestroyedthistick = true
--    end
--end

----------------------------------------------------------
----------- MOD CODE END ----------------------------------