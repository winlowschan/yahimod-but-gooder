-- content.lua - adds SMODS objects for content that should always be loaded (thanks Cryptid!)

